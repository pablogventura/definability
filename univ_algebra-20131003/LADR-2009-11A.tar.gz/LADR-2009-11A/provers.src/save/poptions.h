#ifndef TP_POPTIONS_H
#define TP_POPTIONS_H

#include "prover9.h"

/* INTRODUCTION
*/

/* Public definitions */

/* End of public definitions */

/* Public function prototypes from poptions.c */

void init_prover_options(void);

#endif  /* conditional compilation of whole file */
