To compile: ant

To run:
java -classpath ~/temp/ua/classes/ org.uacalc.alg.conlat.CongruenceLattice >tempout10.txt
