package org.uacalc.example;

import org.uacalc.io.*;
import org.uacalc.alg.*;
import org.uacalc.terms.*;
import org.uacalc.eq.*;
import java.io.*;
import java.util.*;

public class FreeAlg {

  /**
   * @param args
   */
  //  static int[] algAGenerators = new int[] { 0, 1, 2 };
  public static void main(String[] args) {
    // TODO Auto-generated method stub
    if (args.length < 2) {
      System.out.println("need file name of an algebra followed by number of generators");
      return;
    }
    SmallAlgebra algA = null;
    try {
      algA = AlgebraIO.readAlgebraFile(args[0]);
    }
    catch (IOException e) {}             // put an error message here.
    catch (BadAlgebraFileException e) {}
    FreeAlgebra fr = new FreeAlgebra(algA, Integer.parseInt(args[1].trim()));
    System.out.println("fr size = " + fr.cardinality() + " elements");
  }

}
