package org.uacalc.example;

import org.uacalc.io.*;
import org.uacalc.alg.*;
import org.uacalc.alg.conlat.*;
import java.io.*;
import java.util.*;

public class FindTypeSet {

  /**
   * @param args
   */
  public static void main(String[] args) {
    // TODO Auto-generated method stub
    if (args.length == 0) {
      System.out.println("need a file name of an algebra");
      return;
    }
    SmallAlgebra alg = null;
    try {
      alg = AlgebraIO.readAlgebraFile(args[0]);
    }
    catch (IOException e) {}             // put an error message here.
    catch (BadAlgebraFileException e) {}
    TypeFinder tf = new TypeFinder(alg);
    HashSet types = tf.findTypeSet();
    System.out.println("type set: " + types);
  }

}
