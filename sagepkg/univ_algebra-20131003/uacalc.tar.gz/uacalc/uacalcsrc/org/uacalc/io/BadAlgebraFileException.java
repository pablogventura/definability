
package org.uacalc.io;

public class BadAlgebraFileException extends Exception {
    
  public BadAlgebraFileException(String msg) { super(msg); }

}

