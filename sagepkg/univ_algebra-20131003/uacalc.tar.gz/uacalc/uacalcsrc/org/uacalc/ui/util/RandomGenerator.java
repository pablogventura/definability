package org.uacalc.ui.util;

import java.util.*;

public final class RandomGenerator {

  private static final Random random = new Random();
  
  public static final Random getRandom() {
    return random;
  }
  
}
