package org.uacalc.ui;

import javax.swing.JPanel;

public class PropertiesPanel extends JPanel {

}
